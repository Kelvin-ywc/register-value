from setuptools import setup, find_packages

setup(
    name='register_value',
    version='0.0.1',
    packages=find_packages(),
    install_requires = [],
    author='Kelvin',
    author_email='yan18771989297@gmail.com',
    description='A simple global value manager',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)