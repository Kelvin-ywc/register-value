from ._register_value import RegisterValue as _RegisterValue

__version__ = '0.0.1'
__all__ = ['register_value']

register_value = _RegisterValue()